#include "DisplayObserver.h"

// destructor 
DisplayObserver::~DisplayObserver() {}

void DisplayObserver::notify(bool white) {}
