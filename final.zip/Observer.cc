#include "Observer.h"

// destructor 
Observer::~Observer() {}
