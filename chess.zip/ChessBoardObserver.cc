#include "ChessBoardObserver.h"

// destructor 
ChessBoardObserver::~ChessBoardObserver() {}

